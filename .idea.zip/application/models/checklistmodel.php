<?php

/**
 * Created by PhpStorm.
 * User: Nguyen
 * Date: 7/17/14
 * Time: 9:39 AM
 */
class ChecklistModel
{
    public function __construct(PDO $db)
    {
        try {
            $this->db = $db;
        } catch (PDOException $e) {
            exit("Database couldn't established");
        }
    }
    public function getStudent($studentCodes) {
        $query = $this->db->prepare("SET NAMES 'UTF8'");
        $query->execute();
        $sql = "SELECT * FROM student WHERE mssv IN(".$studentCodes.") ORDER BY lname, fname ASC";
        $query = $this->db->prepare($sql);
        $query->execute();
        return $query->fetchAll();
    }
}